---
name: Rural Premium Editorial
colors:
  surface: '#f8fbe7'
  surface-dim: '#d8dcc8'
  surface-bright: '#f8fbe7'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f6e1'
  surface-container: '#edf0dc'
  surface-container-high: '#e7ead6'
  surface-container-highest: '#e1e4d1'
  on-surface: '#191d11'
  on-surface-variant: '#434843'
  inverse-surface: '#2e3225'
  inverse-on-surface: '#eff3df'
  outline: '#737973'
  outline-variant: '#c3c8c1'
  surface-tint: '#4d6453'
  primary: '#061b0e'
  on-primary: '#ffffff'
  primary-container: '#1b3022'
  on-primary-container: '#819986'
  inverse-primary: '#b4cdb8'
  secondary: '#5f5e5a'
  on-secondary: '#ffffff'
  secondary-container: '#e5e2dc'
  on-secondary-container: '#656460'
  tertiary: '#2e0c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#501a00'
  on-tertiary-container: '#d47b53'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d0e9d4'
  primary-fixed-dim: '#b4cdb8'
  on-primary-fixed: '#0b2013'
  on-primary-fixed-variant: '#364c3c'
  secondary-fixed: '#e5e2dc'
  secondary-fixed-dim: '#c9c6c1'
  on-secondary-fixed: '#1c1c18'
  on-secondary-fixed-variant: '#474743'
  tertiary-fixed: '#ffdbcd'
  tertiary-fixed-dim: '#ffb596'
  on-tertiary-fixed: '#360f00'
  on-tertiary-fixed-variant: '#76320f'
  background: '#f8fbe7'
  on-background: '#191d11'
  surface-variant: '#e1e4d1'
typography:
  display-hero:
    fontFamily: Playfair Display
    fontSize: 84px
    fontWeight: '700'
    lineHeight: 96px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
  pull-quote:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '400'
    lineHeight: 36px
  body-lg:
    fontFamily: Montserrat
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 30px
  body-md:
    fontFamily: Montserrat
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  label-caps:
    fontFamily: Montserrat
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.1em
  nav-link:
    fontFamily: Montserrat
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  container-max: 1280px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
  stack-sm: 8px
  stack-md: 24px
  stack-lg: 48px
  stack-xl: 80px
---

## Brand & Style
The design system is built upon a "Modern Heritage" philosophy, bridging the gap between raw, rural Indian landscapes and sophisticated travel journalism. It evokes the feeling of a high-end travel monograph—intellectual, appreciative, and deeply grounded in the earth.

The style is **Premium Editorial**. It utilizes high-contrast typography, generous negative space, and a refined tactile quality. The user experience should feel like turning the pages of a curated journal: intentional, calm, and immersive. Visuals prioritize high-fidelity photography of landscapes and textures over heavy UI decoration.

## Colors
The palette is rooted in the Indian landscape. **Warm Cream (#F9F6F0)** serves as the primary canvas, providing a softer, more organic feel than pure white. **Deep Forest Green (#1B3022)** provides the weight and authority for primary branding and headers.

**Muted Terracotta (#A0522D)** is used sparingly for highlights, calls to action, and storytelling accents, echoing the clay of the earth. **Dark Olive** and **Earth Brown** are reserved for secondary text and borders to maintain a low-contrast, sophisticated hierarchy. Functional states (success/error) should be muted to match this earthy profile, avoiding neon or synthetic tones.

## Typography
This design system employs a classic "Serif for Story, Sans for Utility" pairing. 

**Playfair Display** is the emotional core, used for large-scale headers and pull-quotes to convey elegance and the passage of time. **Montserrat** provides a clean, modern counterpoint for body copy, ensuring high legibility for technical details and travel itineraries. 

Maintain a "loose" line height in body text to enhance the editorial feel. For mobile, headline scales are aggressively reduced to maintain layout integrity while preserving the distinctive serif character.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy on desktop to mimic the structured margins of a magazine. We utilize a 12-column grid with generous external margins to "frame" the content.

Spacing is used as a narrative tool. Large vertical gaps (stack-xl) are used to separate major story beats, allowing the photography and typography to breathe. Content density should remain low; avoid cluttering the view with multiple sidebars or competing modules. On mobile, the grid collapses to a single column with a focus on a singular vertical flow.

## Elevation & Depth
Depth is achieved through **Tonal Layering** rather than traditional shadows. Surfaces are stacked using subtle color shifts—for example, a Warm Cream card sitting on a pure White background.

Where depth is necessary for interaction, use **Ambient Shadows**: extremely diffused, low-opacity (#1B3022 at 5% opacity) shadows that feel like natural light hitting a physical page. Avoid sharp edges or high-contrast drop shadows. For immersive sections, use full-bleed image backgrounds with a Dark Olive overlay to create a "recessed" feel for text overlays.

## Shapes
The shape language is **Soft and Architectural**. We use subtle rounding (0.25rem) to take the edge off digital elements, making them feel more organic and tactile. 

Full-bleed images should remain sharp-edged to maintain the editorial "frame" look, while interactive components like buttons and cards use the soft radius. Circular elements are used only for profile images or specific decorative "stamp" icons to contrast with the predominantly rectangular grid.

## Components

### Buttons
Primary buttons are solid Deep Forest Green with White text, using the "Soft" radius. Secondary buttons use a Dark Olive ghost style (border only) to remain subservient to the primary narrative path.

### Cards
Cards should be used sparingly. They feature a 1px Dark Olive border at 10% opacity or a subtle Tonal Layer. Information should be top-aligned with significant padding (32px+) to maintain the premium feel.

### Input Fields
Fields are minimalist: a bottom-border only approach or a very light Warm Cream fill. Labels use the `label-caps` style for a "form-as-document" aesthetic.

### Chips & Tags
Used for regional categories (e.g., "Rajasthan", "Organic"). These should be Earth Brown with low-contrast text, appearing more like a subtle stamp than a plastic UI element.

### Narrative Pull-Quotes
A bespoke component featuring large serif quotation marks in Terracotta, centered or offset within the text flow to break up long-form body content.